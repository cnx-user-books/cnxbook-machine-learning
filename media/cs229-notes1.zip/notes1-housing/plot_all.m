% generates all housing data figures for cs229 lecture notes 1
%
% dramage 20070919

plot_basic;
pause(1);

plot_regression;
pause(1);

plot_gradient;
